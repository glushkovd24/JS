window.onload = function (){
	var canvas = document.getElementById('canvas');
	var ctx = canvas.getContext('2d');
	var elem1 = document.getElementById("fst");
	var elem2 = document.getElementById("scd");
	var elem3 = document.getElementById("trd");
	var elem4 = document.getElementById("frt");
	var but = document.getElementById('button');
	drawField();
	but.addEventListener('click', function(){
		clear();
		if (elem1.value == elem3.value || elem2.value == elem4.value) drawRight();
		else drawWrong();
	});

	function drawField(){
			var cellWidth = 50;
			var cellHeight = 50;
		for (var i = 0; i < 64; i++){
			var y = Math.floor(i / 8);
			var x = i % 8;
			if ((i + y) % 2 == 0) ctx.fillStyle = "black";
			else ctx.fillStyle = "white";
			ctx.fillRect(x * cellWidth, y * cellHeight, cellWidth, cellHeight);
			}
	}
	function drawRight() {
			ctx.strokeStyle = "green";
			ctx.rect(elem4.value * 50 - 50, 400 - elem3.value * 50, 50, 50);
			ctx.lineWidth = 5;
			ctx.stroke();
			moveImg();
	}
	function drawWrong() {
			ctx.strokeStyle = "red";
			ctx.rect(elem4.value * 50 - 50, 400 - elem3.value * 50, 50, 50);
			ctx.lineWidth = 5;
			ctx.stroke();
			moveImg();
	}
	function moveImg(){
		var pc = document.getElementById("png");
		pc.innerHTML="<img id = 'pic' src='ladya.png'>";
		var pic = document.getElementById("pic");
		pic.style.left = elem2.value * 50 - 50 + 10 + 'px';
		pic.style.top = 400 - elem1.value * 50 + 40 + 'px';
	}
	function clear(){
		canvas.width = canvas.width;
		drawField();
	}
}